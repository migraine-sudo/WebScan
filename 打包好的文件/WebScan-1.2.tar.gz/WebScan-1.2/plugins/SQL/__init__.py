
# -*- coding: utf-8 -*-
'''
测试说明：
地址：http://120.79.174.75/DVWA-master/ #尽量使用手工输入
线程数和深度都写 2 #写其他的会翻车
服务器配置：将DVWA难度设置为low
DVWA账号：admin password
'''