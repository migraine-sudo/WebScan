

def repair():
    return "Check one by one according to the URL found"